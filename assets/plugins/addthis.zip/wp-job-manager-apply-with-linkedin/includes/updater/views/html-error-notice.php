<div class="error">
	<p><?php echo wp_kses_post( $error ); ?></p>
</div>